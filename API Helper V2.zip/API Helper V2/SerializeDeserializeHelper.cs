﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FinOpsRestAPILibrary;
using Newtonsoft.Json;

namespace VLSSARAPIHelper
{
    public class SerializeDeserializeHelper : SerializeDeserializeAbstract
    {
        public override object DeserializeJSON(string _JSON, Type _responseObjectType)
        {
            string typeName = _responseObjectType.Name;
            object ret = null;
            switch (typeName)
            {
                case nameof(ResponseModelClassName):
                    ret = JsonConvert.DeserializeObject<ResponseModelClassName>(_JSON);
                    return ret;
                default:
                    throw new NotImplementedException();
            }
        }
    }
}
